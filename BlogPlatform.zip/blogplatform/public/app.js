(function () {
    angular
      .module("BlogApp",[])
      .controller("BlogController", BlogController);

      function BlogController($scope, $http){
        $scope.createPost = createPost;
        $scope.deletePost = deletePost;
        $scope.editPost = editPost;
        $scope.updatePost = updatePost;

          function init(){
            getAllposts();
          }
          init();

          function updatePost(post){
            $http
              .put("/api/BlogEntry/"+post._id, post)
              .success(getAllposts);
            document.getElementById("blogInput").reset();
          }

          function editPost(postId){
            $http
              .get("/api/BlogEntry/" + postId)
              .success(function(post){
                $scope.post = post;
              });

          }

          function deletePost(postId){
            $http
              .delete("/api/BlogEntry/" + postId)
              .success(getAllposts);

          }

          function getAllposts(){
            $http
              .get("/api/BlogEntry")
              .success(function(posts){
                  $scope.posts = posts;
              });
          }

          function createPost(post){
            console.log(post);
            $http
              .post("/api/BlogEntry", post)
              .success(getAllposts);
            document.getElementById("blogInput").reset();
          }
      }
})();
